import{j as i}from"./jsx-runtime-Jel05txq.js";import{M as o}from"./sidenav-Y75hcptl.js";import{u as c}from"./usa_w_territories-UWRC6Pu1.js";import{u as a}from"./index-09yRmwpQ.js";import"./index-mkCUPuP2.js";/* empty css               */const u={title:"Our network",subtitle:"Send or receive data from our growing network of organizations and public health entities through a single connection.",metaTitle:"Our network - ReportStream",metaDescription:"Send or receive data from our growing network of organizations and public health entities through a single connection.",backToTop:!0},g=[{depth:2,value:"Public health agencies",attributes:{},children:[]},{depth:2,value:"Reporting organizations",attributes:{},children:[{depth:3,value:"SimpleReport",attributes:{},children:[]}]}];function s(n){const e=Object.assign({h2:"h2",p:"p",a:"a",ul:"ul",li:"li",h3:"h3"},a(),n.components),{LayoutSidenav:l,Grid:r}=e;return r||t("Grid",!0),l||t("LayoutSidenav",!0),i.jsxs(i.Fragment,{children:[i.jsx(l,{children:i.jsx(o,{})}),`
`,i.jsx(e.h2,{id:"public-health-agencies",children:"Public health agencies"}),`
`,i.jsx(e.p,{children:"State, local, and territorial agencies across the United States rely on ReportStream to make accurate, timely public health responses."}),`
`,i.jsxs(e.p,{children:["Don't see your state or territory? ",i.jsx(e.a,{href:"https://app.smartsheetgov.com/b/form/48f580abb9b440549b1a9cf996ba6957",children:"Connect with us"}),"."]}),`
`,i.jsxs("figure",{children:[i.jsx("img",{src:c,alt:"Map of states using ReportStream"}),i.jsxs(r,{row:!0,gap:"2",className:"flex-justify-center",children:[i.jsxs(r,{row:!0,gap:"1",children:[i.jsx("div",{className:"flex-align-self-center",children:i.jsx("div",{className:"bg-primary padding-1"})}),i.jsx("div",{children:"Connected"})]}),i.jsxs(r,{row:!0,gap:"1",children:[i.jsx("div",{className:"flex-align-self-center",children:i.jsx("div",{className:"bg-gray-10 padding-1"})}),i.jsx("div",{children:"Not connected"})]})]}),i.jsxs("figcaption",{children:[i.jsx(e.a,{href:"https://commons.wikimedia.org/wiki/File:Blank_USA,_w_territories.svg",children:"Heitordp"}),", CC0, via Wikimedia Commons"]})]}),`
`,i.jsx(e.p,{children:"ReportStream has established connections to report public health data for each of these states and territories."}),`
`,i.jsx("div",{className:"rs-column-3",children:i.jsxs(e.ul,{children:[`
`,i.jsx(e.li,{children:"Alabama"}),`
`,i.jsx(e.li,{children:"Alaska"}),`
`,i.jsx(e.li,{children:"Arkansas"}),`
`,i.jsx(e.li,{children:"Arizona"}),`
`,i.jsx(e.li,{children:"California"}),`
`,i.jsx(e.li,{children:"Colorado"}),`
`,i.jsx(e.li,{children:"Delaware"}),`
`,i.jsx(e.li,{children:"Florida"}),`
`,i.jsx(e.li,{children:"Guam"}),`
`,i.jsx(e.li,{children:"Idaho"}),`
`,i.jsx(e.li,{children:"Illinois"}),`
`,i.jsx(e.li,{children:"Indiana"}),`
`,i.jsx(e.li,{children:"Iowa"}),`
`,i.jsx(e.li,{children:"Kansas"}),`
`,i.jsx(e.li,{children:"Louisiana"}),`
`,i.jsx(e.li,{children:"Maryland"}),`
`,i.jsx(e.li,{children:"Massachusetts"}),`
`,i.jsx(e.li,{children:"Minnesota"}),`
`,i.jsx(e.li,{children:"Mississippi"}),`
`,i.jsx(e.li,{children:"Missouri"}),`
`,i.jsx(e.li,{children:"Montana"}),`
`,i.jsx(e.li,{children:"Nevada"}),`
`,i.jsx(e.li,{children:"New Hampshire"}),`
`,i.jsx(e.li,{children:"New Jersey"}),`
`,i.jsx(e.li,{children:"New Mexico"}),`
`,i.jsx(e.li,{children:"New York"}),`
`,i.jsx(e.li,{children:"North Dakota"}),`
`,i.jsx(e.li,{children:"Ohio"}),`
`,i.jsx(e.li,{children:"Oklahoma"}),`
`,i.jsx(e.li,{children:"Oregon"}),`
`,i.jsx(e.li,{children:"Pennsylvania"}),`
`,i.jsx(e.li,{children:"Rhode Island"}),`
`,i.jsx(e.li,{children:"South Dakota"}),`
`,i.jsx(e.li,{children:"Tennessee"}),`
`,i.jsx(e.li,{children:"Texas"}),`
`,i.jsx(e.li,{children:"Utah"}),`
`,i.jsx(e.li,{children:"Vermont"}),`
`,i.jsx(e.li,{children:"Washington"}),`
`,i.jsx(e.li,{children:"Wyoming"}),`
`]})}),`
`,i.jsx(e.h2,{id:"reporting-organizations",children:"Reporting organizations"}),`
`,i.jsx(e.p,{children:"Labs, testing facilities, and other health care organizations throughout the country are simplifying their data transfer by using ReportStream."}),`
`,i.jsx("div",{className:"rs-column-3",children:i.jsxs(e.ul,{children:[`
`,i.jsx(e.li,{children:"Abbott"}),`
`,i.jsx(e.li,{children:"Aegis"}),`
`,i.jsx(e.li,{children:"Anavasi Diagnostics"}),`
`,i.jsx(e.li,{children:"ARCpoint Labs"}),`
`,i.jsx(e.li,{children:"BASE10 Genetics"}),`
`,i.jsx(e.li,{children:"BZD Labs"}),`
`,i.jsx(e.li,{children:"CLX Health"}),`
`,i.jsx(e.li,{children:"Color"}),`
`,i.jsx(e.li,{children:"CovX Labs"}),`
`,i.jsx(e.li,{children:"Cue Health"}),`
`,i.jsx(e.li,{children:"Dendi Software"}),`
`,i.jsx(e.li,{children:"Ellume"}),`
`,i.jsx(e.li,{children:"Genabio Diagnostics"}),`
`,i.jsx(e.li,{children:"Healthcare Integrations"}),`
`,i.jsx(e.li,{children:"iHealth"}),`
`,i.jsx(e.li,{children:"ImageMover"}),`
`,i.jsx(e.li,{children:"Innolitics"}),`
`,i.jsx(e.li,{children:"Intrivo"}),`
`,i.jsx(e.li,{children:"LIMSABC"}),`
`,i.jsx(e.li,{children:"Mayo Clinic"}),`
`,i.jsx(e.li,{children:"MedArbor Diagnostics"}),`
`,i.jsx(e.li,{children:"Medical Network Solutions"}),`
`,i.jsx(e.li,{children:"MP Biomedicals"}),`
`,i.jsx(e.li,{children:"Premier Medical Group"}),`
`,i.jsx(e.li,{children:"Prescryptive"}),`
`,i.jsx(e.li,{children:"Primary.Health"}),`
`,i.jsx(e.li,{children:"Reddy Family Medical Clinic"}),`
`,i.jsx(e.li,{children:"Safe Health Systems"}),`
`,i.jsx(e.li,{children:"SDI Labs"}),`
`,i.jsx(e.li,{children:"Signetic"}),`
`,i.jsx(e.li,{children:"Simple HealthKit"}),`
`,i.jsx(e.li,{children:"Sonic Healthcare"}),`
`,i.jsx(e.li,{children:"Strac"}),`
`,i.jsx(e.li,{children:"Xtrava Health"}),`
`]})}),`
`,i.jsx(e.h3,{id:"simplereport",children:"SimpleReport"}),`
`,i.jsxs(e.p,{children:[`Our network expands beyond the organizations directly using ReportStream and includes the testing sites
and providers using SimpleReport as well. Data reported by using `,i.jsx(e.a,{href:"https://www.simplereport.gov",children:"SimpleReport"}),`,
our sister project from the CDC, is sent to public health agencies through ReportStream.`]})]})}function f(n={}){const{wrapper:e}=Object.assign({},a(),n.components);return e?i.jsx(e,Object.assign({},n,{children:i.jsx(s,n)})):s(n)}function t(n,e){throw new Error("Expected "+(e?"component":"object")+" `"+n+"` to be defined: you likely forgot to import, pass, or provide it.")}export{f as default,u as frontmatter,g as toc};
