const e="_Table_lmur6_1453",_="_Table__StickyHeader_lmur6_1516",a={Table:e,Table__StickyHeader:_};export{a as s};
