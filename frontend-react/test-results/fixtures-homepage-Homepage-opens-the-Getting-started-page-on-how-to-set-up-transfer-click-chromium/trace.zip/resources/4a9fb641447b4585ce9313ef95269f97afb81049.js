var r=(e=>(e.PRIMEADMINS="PrimeAdmins",e.IGNORE="ignore",e))(r||{});const n=e=>e==="PrimeAdmins"?"ignore":e;export{r as O,n as u};
