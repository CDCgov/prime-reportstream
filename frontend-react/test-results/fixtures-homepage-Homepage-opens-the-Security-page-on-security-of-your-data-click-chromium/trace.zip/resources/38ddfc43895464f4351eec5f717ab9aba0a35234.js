const s="/assets/app/usa_w_territories-B1dLI24o.svg";export{s as u};
